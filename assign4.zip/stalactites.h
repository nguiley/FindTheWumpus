#ifndef STALACTITES_H
#define STALACTITES_H 

#include "event.h"

//Stalactites Interface
class Stalactites : public Event {
private:
    bool game_over = false;
public:
    Stalactites();
    void perform_action();
    bool get_game_over();
};

#endif
