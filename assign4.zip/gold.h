#ifndef GOLD_H
#define GOLD_H 
#include "event.h"

//Gold Interface
class Gold : public Event {
private:
    bool gold_collected = false;
public:
    Gold();
    void perform_action();
    bool get_gold_collected();
};

#endif