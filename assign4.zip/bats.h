#ifndef BATS_H
#define BATS_H 
#include "event.h"

//Bats Interface
class Bats : public Event {
private:

public:
    Bats();
    ~Bats();
    void perform_action();
};

#endif