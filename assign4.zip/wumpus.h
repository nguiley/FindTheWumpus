#ifndef WUMPUS_H
#define WUMPUS_H 

#include "event.h"

//Wumpus Interface
class Wumpus : public Event {
private:

public:
    Wumpus();
    void perform_action();
};

#endif