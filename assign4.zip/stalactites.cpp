/******************************************************
** Program: stalactites.cpp
** Author: Nicholas Guiley
** Date: 11/28/2023
** Description: Implements the stalactites class
** Input: stalactites declared
** Output: stalactites out of scope
******************************************************/
#include "stalactites.h"

#include <iostream>

using namespace std;

Stalactites::Stalactites() {
    this->percept = "You hear water dripping.";
}

void Stalactites::perform_action() {
    int rand_num = rand() % 2;
    if (rand_num == 0) {
        cout << "\n\nA stalactite fell on your head!!" << endl;
        this->game_over = true;
    }
}

bool Stalactites::get_game_over() {
    return this->game_over;
}