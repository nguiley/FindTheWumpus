/******************************************************
** Program: bats.cpp
** Author: Nicholas Guiley
** Date: 11/28/2023
** Description: Implements the bats class
** Input: bats declared
** Output: bats out of scope
******************************************************/
#include "bats.h"

#include <iostream>

using namespace std;

//Bats Implementation
Bats::Bats() {
    this->percept = "You hear wings flapping.";
}

Bats::~Bats() {
    // cout << "Bats destructor" << endl;
}

void Bats::perform_action() {
    cout << "Bats action not implemented" << endl;
}