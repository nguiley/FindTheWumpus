/******************************************************
** Program: wumpus.cpp
** Author: Nicholas Guiley
** Date: 11/28/2023
** Description: Implements the wumpus class
** Input: wumpus declared
** Output: wumpus out of scope
******************************************************/
#include "wumpus.h"

#include <iostream>

using namespace std;

Wumpus::Wumpus() {
    this->percept = "You smell a terrible stench.";
}

void Wumpus::perform_action() {
    cout << "\n\nYou Were Eaten!!" << endl;
}