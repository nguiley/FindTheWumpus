#ifndef GAME_H
#define GAME_H 

#include <vector>
#include <iostream> 
#include "room.h"
#include "gold.h"
#include "stalactites.h"
#include "bats.h"
#include "wumpus.h"

using namespace std;

class Game {
private:
	Bats* b1 = new Bats;
	Bats* b2 = new Bats;
	Stalactites* s1 = new Stalactites;
	Stalactites* s2 = new Stalactites;
	Wumpus* w = new Wumpus;
	Gold* g = new Gold;
	vector<vector<Room>> board; // 2d vector of room objects
	int rows; 			//length of the board
	int columns;  			//width of the board
	int num_arrows; 		//keep track of number of errors remaining
	bool debug_view;		//debug mode or not
	int player_row; // updated by moving (up and down)
	int player_column; // updated by moving (left and right)
	int start_row;
	int start_column;
	vector<vector<bool>> used_rooms;
	bool wumpus_dead = false;
	bool gold_collected = false;
	bool won = false;
	bool game_over = false;
	int confusion_turns = 0;

public:
	Game();
	~Game();
	void set_up_used_rooms();
	void set_up(int, int);
	void insert_player();
	void insert_event(Event*);
	string icon_condition(int, int, string) const;
	string display_icons(int row, string s) const;
	void display_game() const;
	void check_win();
	char get_dir();
	void wumpus_move();
	void fire_arrow();
	void move_up();
	void move_down();
	void move_left();
	void move_right();
	void move(char);
	void print_options() const;
	char get_input();
	void events();
	void play_game(int, int, bool);
	void set_debug_view(bool);
	void display_percepts();
};
#endif