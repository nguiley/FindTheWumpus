/******************************************************
** Program: event.cpp
** Author: Nicholas Guiley
** Date: 11/28/2023
** Description: Implements the event class
** Input: event declared
** Output: event out of scope
******************************************************/
#include "event.h"

#include <iostream>

using namespace std;

Event::Event() {}

Event::~Event() {}

string Event::get_percept() const {
    return this->percept;
}

int Event::get_row() const {
    return this->event_row;
}

int Event::get_column() const {
    return this->event_column;
}

void Event::set_row(int row) {
    this->event_row = row;
}

void Event::set_column(int column) {
    this->event_column = column;
}