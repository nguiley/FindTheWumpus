/******************************************************
** Program: main.cpp
** Author: Nicholas Guiley
** Date: 11/28/2023
** Description: Implements the main class
** Input: program started
** Output: program ended
******************************************************/
#include <iostream>
#include <cstdlib>
#include <ctime>
#include "game.h"

using namespace std;

int get_input(string msg, string invalid, int lower, int upper) {
    int length = upper - lower + 1; // length of array [lower - upper] inclusive
    string* array = new string[length];
    while (true) {
        string input;
        cout << msg;
        cin >> input;
        for (int i = 0; i < length; i++) {
            array[i] = to_string(lower + i); // populates array [lower - upper] inclusive
            if (array[i] == input) { // checks if user input is within the array
                delete [] array;
                return lower + i;
            }
        }
        cout << invalid << endl; // only runs if user input is not within fully populated array
    }
}

string get_debug_mode() {
    string choice;
    do {
        cout << "Enter y to enter game in debug view or n otherwise (lowercase): ";
        cin >> choice;
        if (choice != "y" && choice != "n") {
            cout << "Invalid choice" << endl;
        }
    } while (choice != "y" && choice != "n");
    return choice;
}

int main() {
	//set the random seed
	srand(time(NULL));
	bool debug = false;
	
	Game g;
	//get two inputs: size of the cave(wid and len)
	int len, wid;
	len = get_input("Enter the length of the grid (between 4 and 50 inclusive): ", "Invalid input.", 4, 50);
	wid = get_input("Enter the width of the grid (between 4 and 50 inclusive): ", "Invalid input.", 4, 50);
	//get the 3rd input --> debug mode or not
    string choice = get_debug_mode();
    if (choice == "y") {
        debug = true;
    }
	//Play game
	g.play_game(wid, len, debug);
}