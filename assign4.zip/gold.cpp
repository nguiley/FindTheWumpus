/******************************************************
** Program: gold.cpp
** Author: Nicholas Guiley
** Date: 11/28/2023
** Description: Implements the gold class
** Input: gold declared
** Output: gold out of scope
******************************************************/
#include "gold.h"

#include <iostream>

using namespace std;

//Gold Implementation
Gold::Gold() {
    this->percept = "You see a glimmer nearby.";
}

void Gold::perform_action() {
    this->gold_collected = true;
}

bool Gold::get_gold_collected() {
    return this->gold_collected;
}