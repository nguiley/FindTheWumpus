#ifndef EVENT_H
#define EVENT_H 
#include <string>

using namespace std;

//Event Interface
//Note: this must be an abstract class!

class Event {
protected:
    int event_row;
    int event_column;
    string percept;

public:
    Event();
    virtual ~Event();
	virtual void perform_action() = 0;
    string get_percept() const;
    int get_row() const;
    int get_column() const;
    void set_row(int row);
    void set_column(int column);
};
#endif