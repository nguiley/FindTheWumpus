/******************************************************
** Program: game.cpp
** Author: Nicholas Guiley
** Date: 11/28/2023
** Description: Implements the game class
** Input: Game started
** Output: Game ended
******************************************************/
#include "game.h"

using namespace std;

Game::Game() {}

Game::~Game() {
	delete b1;
	delete b2;
	delete s1;
	delete s2;
	delete w;
	delete g;
}

void Game::set_up_used_rooms() {
	this->used_rooms.resize(rows);
	for (int i = 0; i < rows; i++) {
		this->used_rooms.at(i).resize(columns);
	}
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < columns; j++) {
			this->used_rooms.at(i).at(j) = false;
		}
	}
}

void Game::set_up(int columns, int rows) {
	//set up the game
	this->rows = rows;
	this->columns = columns;
	this->num_arrows = 3; 	//start with 3 arrows
	set_up_used_rooms();
	// Create the game board: 2D vector of Room objects
	this->board.resize(rows);
	for (int i = 0; i < rows; i++) {
		this->board.at(i).resize(columns);
	}
	// randomly insert events (2 bats, 2 stalactites, 1 wumpus, 1 gold)
	this->insert_event(b1);
	this->insert_event(b2);
	this->insert_event(s1);
	this->insert_event(s2);
	this->insert_event(w);
	this->insert_event(g);
	this->insert_player();
}

void Game::insert_player() {
	int rand_row; // random row
	int rand_column; // random column
	do {
		rand_row = rand() % rows;
		rand_column = rand() % columns;
		if (!used_rooms.at(rand_row).at(rand_column)) {
			this->start_row = rand_row;
			this->start_column = rand_column;
		}
	} while(used_rooms.at(rand_row).at(rand_column));
	used_rooms.at(rand_row).at(rand_column) = true;
	this->player_row = this->start_row;
	this->player_column = this->start_column;
}

void Game::insert_event(Event* e) {
	int rand_row; // random row
	int rand_column; // random column
	do {
		rand_row = rand() % rows;
		rand_column = rand() % columns;
		if (!used_rooms.at(rand_row).at(rand_column)) {
			board.at(rand_row).at(rand_column).set_event(e); // set random room's event
		}
	} while(used_rooms.at(rand_row).at(rand_column));
	used_rooms.at(rand_row).at(rand_column) = true;
	e->set_row(rand_row);
	e->set_column(rand_column);
}

string Game::icon_condition(int row, int i, string s) const {
	if (row == this->player_row && i == this->player_column) {
		s += "| * ";
	} else if (row == this->start_row && i == this->start_column) {
		s += "| / ";
	} else if ((row == b1->get_row() && i == b1->get_column()) || (row == b2->get_row() && i == b2->get_column())) {
		s += "| B ";
	} else if ((row == s1->get_row() && i == s1->get_column()) || (row == s2->get_row() && i == s2->get_column())) {
		s += "| S ";
	} else if (row == w->get_row() && i == w->get_column() && !wumpus_dead) {
		s += "| W ";
	} else if (row == g->get_row() && i == g->get_column() && !gold_collected) {
		s += "| G ";
	} else {
		s += "|   ";
	}
	return s;
}

string Game::display_icons(int row, string s) const {
	for (int i = 0; i < columns; i++) {
		if (debug_view) {
			string pass;
			s += Game::icon_condition(row, i, pass);
		} else {
			if (row == this->player_row && i == this->player_column) {
				s += "| * ";
			} else {
				s += "|   ";
			}
		}
	}
	return s += "|\n";
}

void Game::display_game() const {
	cout << endl << endl;
	if (!this->won && !this->game_over) {
		cout << "Arrows remaining: " << this->num_arrows << endl << endl;
	}
	string str = "";
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < columns; j++) {
			str += "+---";
		}
		str += "+\n";
		string s;
		str += display_icons(i, s);
	}
	for (int i = 0; i < columns; i++) {
		str += "+---";
	}
	str += "+\n";
	cout << str << endl;
}

void Game::check_win() {
	//check if game over/win
	if (this->wumpus_dead || (this->gold_collected && (this->player_row == start_row && this->player_column == start_column))) {
		this->won = true;
		cout << "\n\nYou Win!!" << endl << endl;
	}
}

void Game::move_up() {
	//move player up
	if (this->confusion_turns == 0) {
		if (this->player_row == 0) {
			cout << "Cannot move up, path blocked." << endl;
		} else {
			this->player_row--;
		}
	} else {
		if (this->player_row == this->rows - 1) {
			cout << "Cannot move, path blocked." << endl;
		} else {
			this->player_row++;
			this->confusion_turns--;
		}
	}
}

void Game::move_down() {
	//move player down
	if (this->confusion_turns == 0) {
		if (this->player_row == this->rows - 1) {
			cout << "Cannot move down, path blocked." << endl;
		} else {
			this->player_row++;
		}
	} else {
		if (this->player_row == 0) {
			cout << "Cannot move, path blocked." << endl;
		} else {
			this->player_row--;
			this->confusion_turns--;
		}
	}
}

void Game::move_left() {
	//move player left
	if (this->confusion_turns == 0) {
		if (this->player_column == 0) {
			cout << "Cannot move left, path blocked." << endl;
		} else {
			this->player_column--;
		}
	} else {
		if (this->player_column == this->columns - 1) {
			cout << "Cannot move, path blocked." << endl;
		} else {
			this->player_column++;
			this->confusion_turns--;
		}
	}
}

void Game::move_right() {
	//move player right
	if (this->confusion_turns == 0) {
		if (this->player_column == this->columns - 1) {
			cout << "Cannot move right, path blocked." << endl;
		} else {
			this->player_column++;
		}
	} else {
		if (this->player_column == 0) {
			cout << "Cannot move, path blocked." << endl;
		} else {
			this->player_column--;
			this->confusion_turns--;
		}
	}
}

char Game::get_dir() {
	//get direction of arrow:
	char dir;
	cout << "\nFire an arrow...." << endl;
	cout << "W-up" << endl;
	cout << "A-left" << endl;
	cout << "S-down" << endl;
	cout << "D-right" << endl;
	do {
		cout << "Enter direction (lowercase): ";
		cin >> dir;
		cin.ignore(256, '\n');
		if (dir != 'w' && dir != 'a' && dir != 's' && dir != 'd') {
            cout << "Invalid choice" << endl;
        }
	} while (dir != 'w' && dir != 'a' && dir != 's' && dir != 'd');
	return dir;
}

void Game::wumpus_move() {
	//after a missed arrow, 75% chance that the wumpus is moved to a different room
	int rand_num = rand() % 4;
	if (rand_num > 0) {
		int rand_row; // random row
		int rand_column; // random column
		do {
			rand_row = rand() % rows;
			rand_column = rand() % columns;
			used_rooms.at(this->w->get_row()).at(this->w->get_column()) = false;
			this->w->set_row(rand_row);
			this->w->set_column(rand_column);
			if (!used_rooms.at(rand_row).at(rand_column)) {
				board.at(rand_row).at(rand_column).set_event(this->w); // set random room's event
			}
		} while(used_rooms.at(rand_row).at(rand_column));
		used_rooms.at(rand_row).at(rand_column) = true;
	}
}

void Game::fire_arrow() { // longer than 15 lines because each condition is different and should be kept together in 1 function
	char dir = get_dir();
	if (dir == 'w' && !wumpus_dead) {
		if ((this->player_row - 1 == this->w->get_row() || this->player_row - 2 == this->w->get_row() || this->player_row - 3 == this->w->get_row()) && this->player_column == this->w->get_column()) {
			wumpus_dead = true;
		} else {
			wumpus_move();
		}
	} else if (dir == 'a' && !wumpus_dead) {
		if ((this->player_column - 1 == this->w->get_column() || this->player_column - 2 == this->w->get_column() || this->player_column - 3 == this->w->get_column()) && this->player_row == this->w->get_row()) {
			wumpus_dead = true;
		} else {
			wumpus_move();
		}
	} else if (dir == 's' && !wumpus_dead) {
		if ((this->player_row + 1 == this->w->get_row() || this->player_row + 2 == this->w->get_row() || this->player_row + 3 == this->w->get_row()) && this->player_column == this->w->get_column()) {
			wumpus_dead = true;
		} else {
			wumpus_move();
		}
	} else if (dir == 'd' && !wumpus_dead) {
		if ((this->player_column + 1 == this->w->get_column() || this->player_column + 2 == this->w->get_column() || this->player_column + 3 == this->w->get_column()) && this->player_row == this->w->get_row()) {
			wumpus_dead = true;
		} else {
			wumpus_move();
		}
	}
	this->num_arrows--;
}

void Game::move(char c) { // Part of the skeleton code
	// Handle player's action: move or fire an arrow
	if (c == 'f') {
		Game::fire_arrow();
		return;
	}
	switch(c) {
		case 'w':
			Game::move_up();
			break;
		case 'a':
			Game::move_left();
			break;
		case 's':
			Game::move_down();
			break;
		case 'd':
			Game::move_right();
			break;
	}
}

void Game::print_options() const {
	cout << endl << "Player move..." << endl << endl;
	cout << "W-up" << endl;
	cout << "A-left" << endl;
	cout << "S-down" << endl;
	cout << "D-right" << endl;
	cout << "f-fire an arrow" << endl;
}

char Game::get_input() {
	//get action, move direction or firing an arrow
	char c;
	Game::print_options();
	do {
		do {
			cout << "Enter input (lowercase): ";
			cin >> c;
			cin.ignore(256, '\n');
			if (c != 'w' && c != 'a' && c != 's' && c != 'd' && c != 'f') {
				cout << "Invalid choice" << endl;
			}
		} while (c != 'w' && c != 'a' && c != 's' && c != 'd' && c != 'f');
		if (c == 'f' && this->num_arrows == 0) {
			cout << "Out of arrows." << endl;
		}
	} while (c == 'f' && this->num_arrows == 0);
	return c;
}

void Game::events() {
	if ((this->player_row == this->b1->get_row() && this->player_column == this->b1->get_column()) || (this->player_row == this->b2->get_row() && this->player_column == this->b2->get_column())) {
		this->confusion_turns = 5;
	} else if ((this->player_row == this->s1->get_row() && this->player_column == this->s1->get_column()) || (this->player_row == this->s2->get_row() && this->player_column == this->s2->get_column())) {
		this->s1->perform_action();
		this->game_over = this->s1->get_game_over();
	} else if (!this->gold_collected && this->player_row == this->g->get_row() && this->player_column == this->g->get_column()) {
		this->g->perform_action();
		this->gold_collected = this->g->get_gold_collected();
	} else if (!this->wumpus_dead && this->player_row == this->w->get_row() && this->player_column == this->w->get_column()) {
		this->w->perform_action();
		this->game_over = true;
	}
}

void Game::play_game(int w, int l, bool d) {
	Game::set_up(w, l);
	this->debug_view = d;
	char input, arrow_input;
	while (!this->won && this->game_over == false) {
		Game::display_game();
		Game::display_percepts();
		input = Game::get_input();
		Game::move(input);
		Game::events();
		Game::check_win();
	}
	Game::display_game();
}

void Game::set_debug_view(bool debug_view) {
	this->debug_view = debug_view;
}

void Game::display_percepts() {
	if ((this->player_row + 1 == this->b1->get_row() && this->player_column == this->b1->get_column()) || (this->player_row - 1 == this->b1->get_row() && this->player_column == this->b1->get_column()) || (this->player_column + 1 == this->b1->get_column() && this->player_row == this->b1->get_row()) || (this->player_column - 1 == this->b1->get_column() && this->player_row == this->b1->get_row())) {
		cout << b1->get_percept() << endl;
	}
	if ((this->player_row + 1 == this->b2->get_row() && this->player_column == this->b2->get_column()) || (this->player_row - 1 == this->b2->get_row() && this->player_column == this->b2->get_column()) || (this->player_column + 1 == this->b2->get_column() && this->player_row == this->b2->get_row()) || (this->player_column - 1 == this->b2->get_column() && this->player_row == this->b2->get_row())) {
		cout << b2->get_percept() << endl;
	}
	if ((this->player_row + 1 == this->s1->get_row() && this->player_column == this->s1->get_column()) || (this->player_row - 1 == this->s1->get_row() && this->player_column == this->s1->get_column()) || (this->player_column + 1 == this->s1->get_column() && this->player_row == this->s1->get_row()) || (this->player_column - 1 == this->s1->get_column() && this->player_row == this->s1->get_row())) {
		cout << s1->get_percept() << endl;
	}
	if ((this->player_row + 1 == this->s2->get_row() && this->player_column == this->s2->get_column()) || (this->player_row - 1 == this->s2->get_row() && this->player_column == this->s2->get_column()) || (this->player_column + 1 == this->s2->get_column() && this->player_row == this->s2->get_row()) || (this->player_column - 1 == this->s2->get_column() && this->player_row == this->s2->get_row())) {
		cout << s2->get_percept() << endl;
	}
	if (!this->wumpus_dead && ((this->player_row + 1 == this->w->get_row() && this->player_column == this->w->get_column()) || (this->player_row - 1 == this->w->get_row() && this->player_column == this->w->get_column()) || (this->player_column + 1 == this->w->get_column() && this->player_row == this->w->get_row()) || (this->player_column - 1 == this->w->get_column() && this->player_row == this->w->get_row()))) {
		cout << w->get_percept() << endl;
	}
	if (!this->gold_collected && ((this->player_row + 1 == this->g->get_row() && this->player_column == this->g->get_column()) || (this->player_row - 1 == this->g->get_row() && this->player_column == this->g->get_column()) || (this->player_column + 1 == this->g->get_column() && this->player_row == this->g->get_row()) || (this->player_column - 1 == this->g->get_column() && this->player_row == this->g->get_row()))) {
		cout << g->get_percept() << endl;
	}
}