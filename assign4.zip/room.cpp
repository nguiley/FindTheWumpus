/******************************************************
** Program: room.cpp
** Author: Nicholas Guiley
** Date: 11/28/2023
** Description: Implements the room class
** Input: room declared with an event
** Output: room out of scope
******************************************************/
#include "room.h"

using namespace std;
Room::Room() {
    this->e = nullptr;
    this->col = 0;
    this->row = 0;
}

void Room::set_event(Event* new_event) {
    if (this->e != nullptr) {
        delete this->e;
    }
    this->e = new_event;
}

Event* Room::get_event() const {
    return  this->e;
}